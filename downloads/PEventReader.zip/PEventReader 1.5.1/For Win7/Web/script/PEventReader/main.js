﻿function init(){
    out = $("out");
    log = $("log");

    isConnect = true;

    if (typeof pwd == "undefined")
    {
        var strLogin1Table  = "<tr> <td class=borderHid style='text-align:left'> <label>Пароль: <input id='pwdInput' type='password'></label> <button onClick='wsReconnect()'>Подключиться</button> </td> </tr>";
        mTable0 = document.createElement("table");
        mTable0.innerHTML = strLogin1Table;
        if (out) out.appendChild(mTable0);

        mTable = document.createElement("table");
        if (out) out.appendChild(mTable);
    }
    else {
        mTable = document.createElement("table");
        if (out) out.appendChild(mTable);
        newWS();
    }
}
//---------------------------------------------------------------------------
function wsReconnect()
{
    var obj=$("pwdInput");

    if (obj) {
        pwd = b64_sha1( obj.value );
        newWS()
    }
}
//---------------------------------------------------------------------------
function newWS(){
    if (isConnect){
        isConnect=false;
        writeLog("Попытка подключения " + wsUri);
    }

    if (typeof websocket == "object") delete websocket;
    websocket = new WebSocket(wsUri);
    websocket.onopen   = function(evt) { onOpen   (evt) };
    websocket.onclose  = function(evt) { onClose  (evt) };
    websocket.onerror  = function(evt) { onError  (evt) };
    websocket.onmessage= function(evt) { onMessage(evt) };
}
//---------------------------------------------------------------------------
function wsSend(msg) {if (typeof websocket == "object") websocket.send( JSON.stringify(msg) );}
function onOpen(evt) {isConnect=true; writeLog("Удачно."); mTable.innerHTML = ""; wsSend( {funct:"pwd", pwd:pwd} );}
function onError(evt){if (isConnect) writeLog("Ошибка.");}
//---------------------------------------------------------------------------
function onClose(evt){
    if (typeof websocket == "object") delete websocket;
    if (isConnect){
        writeLog("Отключение.");

        mTable.innerHTML = "";
    }
    window.setTimeout(newWS, 1000);
}
//---------------------------------------------------------------------------
function onMessage(evt)
{
    var data = JSON.parse(evt.data);

    if (data.funct=="pwd")
    {
        if (data.ret==true)
        {
            if (typeof mTable0 != "undefined") mTable0.innerHTML = "";
            wsSend( {funct:"getEvents", first:-1,count:20} );
        }
        else writeLog("Неудачная авторизация рабочего места. Смотрите лог сервера.");
    }
    else if (data.funct=="getEvents") updateEvents(data.first, data.count, data.total, data.ret);
}
//---------------------------------------------------------------------------
function updateEvents(first, count, total, ret)
{
    if (mTable) {
        var table = document.createElement("table");
        var str = "<tr><th>№</th><th>Дата</th><th>Время</th><th>Событие</th><th>Раздел</th><th>Зона</th><th>Описание</th><th>Прибор</th><th>Хозорган</th><th>Тревога</th></tr>";

        for (var i=0; i<count; i++){
            var obj = ret[i];
            if (obj){
                var n = first + i;
                var evnt = obj.evnt;
                var group= eventsGroup(evnt);
                var event = (obj.rvnt.length==0) ? strEvent(evnt) : obj.rvnt;
                var date = new Date(obj.date*1);

                str += "<tr style='background-color:"+evGColorBG(group)+";color:"+evGColorFG(group)+";'>"+
                        "<td>"+n+"</td>" +
                        "<td>"+date.toLocaleDateString()+"</td>" +
                        "<td>"+date.toLocaleTimeString()+"</td>" +
                        "<td>"+event   +"</td>" +
                        "<td>"+obj.part+"</td>" +
                        "<td>"+obj.zone+"</td>" +
                        "<td>"+obj.dscr+"</td>" +
                        "<td>"+obj.addr+"</td>" +
                        "<td>"+obj.user+"</td>" +
                        "<td>"+(eventsAlarm(evnt) ? "(!)" :"") +"</td></tr>";
            }
        }

        table.innerHTML = str;
        mTable.innerHTML = "";
        mTable.innerHTML = "<div style='text-align: left;'>Всего событий в базе: "+total+
                "<label>. Отображать: <select id='inpEConut'><option value='20'>20</option><option value='50'>50</option><option value='100'>100</option><option value='250'>250</option><option value='500'>500</option><option value='1000'>1000</option></select></label>"+
                "<label> Отображать c:<input id='inpENumb' type='text' size='6' value='-1'>  ('-1' - последние, автопрокрутка новых)  </label>"+
                "<input type='submit' value='Применить' onClick='updateTableEvents()'></div>";
        mTable.appendChild(table);
    }
}
//---------------------------------------------------------------------------
function updateTableEvents(){
    var objEConut =$("inpEConut");
    var objENumb  =$("inpENumb");

    if (objEConut && objENumb)
        wsSend( {funct:"getEvents", first:Number.parseInt(objENumb.value), count:Number.parseInt(objEConut.value)} );
}
//---------------------------------------------------------------------------
function writeLog(msg) {
    if (log){
        var date = new Date;
        var p = document.createElement("kbd");
        p.innerHTML = "["+date.toLocaleTimeString() +"] "+ msg + "<br>";
        log.appendChild(p);
    }
}
//---------------------------------------------------------------------------
function $(x){obj=document.getElementById(x); return (obj) ? obj:false}
//---------------------------------------------------------------------------
if (window.addEventListener) window.addEventListener("load", init, false);
else{
    window.onload =init;
    writeLog("Технология WebSocket поддерживается в Internet Explorer начиная с версии 10.");
}


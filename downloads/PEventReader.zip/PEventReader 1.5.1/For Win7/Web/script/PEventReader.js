//for ie
document.createElement("section");
document.createElement("header");
document.createElement("nav");
document.createElement("article");
document.createElement("aside");
document.createElement("footer");

function header(){document.write('<h1>PEventReader</h1><p>Интеграция PEventReader с Web при помощи технологий: WebSocket и Json.</p>');}
function nav(){document.write('<ul id="nav"><li><a href="index.htm">Главная</a></li><li><a href="work.htm">Подключение</a></li><li><a href="news.htm">Новости</a></li></ul>');}
function footer(){document.write('www.arm-skif.ru');}

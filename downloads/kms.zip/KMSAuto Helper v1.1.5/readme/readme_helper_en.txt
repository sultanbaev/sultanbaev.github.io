﻿
	 		   KMSAuto Helper from Ratiborus
			—————————————————————————————————


 			    Purpose of the program
			—————————————————————————————————
The program starts with Windows and is located in the system tray, it provides real-time
licensing information of installed M$ products. The program works automatically, with timer function helps you to reactivate
the selected products. This tool uses task in Task Scheduler to reactivate the products, the software will do everything itself, in
accordance to your settings.
The program activates Windows VL editions: Vista, 7, 8, 8.1, 10 Server 2008, 2008 R2, 2012, 2012 R2
as well as Office 2010, 2013/2016Windows 7 Ultimate is not supported.
The integrated KMS-Service activates MAK and RETAIL products with the installation of GVLK (KMS) keys, it is necessary to 
establish appropriate checkboks in tuning of program. 
With KMSAuto Net the activation occurs according to the rules of KMSAuto Net.

 			    Program settings
			—————————————————————————————————
To change the operating mode of the program, you can just run another copy of the program and
select the appropriate setting. You can run the program with the following switches :

/hidden		-The Program will run in a hidden form, a blank screen is displayed.
/normal		-The program will start displaying icons and windows.

If you have problems with activation mode operation without display windows program icon
will appear in the tray with the appropriate message and will disappear after the recovery of activation.

 		   Portable mode of the program
		—————————————————————————————————————————————————————
In this mode nothing is saved on your computer after use, the program always starts
"like the first time." In this mode it is possible to observe the state of the license of the products to
perform activation. Convenient to perform single activations without installation on the system.
As well as the normal mode can be used to activate with KMSAuto Net.
To validate the portable mode of the program, the "helper.ini" file must be placed in the program
directory, this mode is determined only by the existence of this file.
Maybe later the settings will be saved in this file or something like that ... But it will be then. Maybe will... :)
If you run in this mode and a working copy of the program is detected, change the mode of the installed copy of the program, after selecting any setting,
and press "Cancel" button, the program will run in portable mode.
In order KMSAuto Net works together with KMSAuto Helper, it must be configured to work without
saving the settings on the system.

 		       		Removing the program
		—————————————————————————————————————————————————————
In order to completely remove the program you must be on the "Settings" tab click
"Delete Program Settings" and exit the program by selecting the right mouse button on
tray icon and select "Quit".

 		       "And I did not activate!!!!"
		—————————————————————————————————————————————————————
Enable "Use KMSAuto Net" and repeat the activation (KMSAuto Net.exe
near KMSAuto Helper). If still not activated, then you have a non VL product,
not intended for activation of KMS-Service (Windows 7 Ultimate is not supported), 
or your antivirus blocks activation.


Changes in version:
v1.1.5
 -Conversion from Office 2016 Standard, ProjectStd, VisioStd RETAIL to VL.

v1.1.4
 -Conversion from Office 2016 Word, Excel, Access,
  OneNote, OutLook, PowerPoint, Publisher RETAIL to VL.

v1.1.3
 -Minor changes in the interface, eliminate minor errors.

v1.1.2
 -Minor changes in the interface.

v1.1.1 
 -The Program has become multilingual, thanks to my fellow translator. 
 -The program, when attempting activation of Office 2013 RETAIL converts the license channel 
  of OfficeProPlus, VisioPro, ProjectPro on Windows 7, 8, 8.1, 10 to KMS client.


v1.0.9
 -The program works fine on Windows 9860 Technical Preview build.
 -Changed the output of information about products.

v1.0.8
 -Added portable mode of the program.
 -Minor changes in the interface, eliminate minor errors.

v1.0.7.1
 -Changed the mechanism for switching the operating mode of the program.

v1.0.7
 -Improved reliability of the activation of Office 2010 on systems other than Windows 7.
 -Added configuration program by running with command line parameters.

v1.0.6
 -Fixed MAK key of Office 14 not properly reinstalled on Windows 10 Technical Preview.

v1.0.5.1
 -With this version, if the product is not activated with MAK or RETAIL key
  the program tries to install and activate with a GVLK key.
  If the product is activated, it will be skipped for installation of
  GVLK keys or need to install the appropriate in the checkbox, or set key in the menu by the right mouse button.
 -Improved integration with KMSAuto Net ..

v1.0.4
 -Fixed Office 2014 is not activated on Windows 8.1 and Server 2012 R2.

v1.0.3
 -The program works independently of KMSAuto Net.
 -The program has integrated KMS-Service.
 -Added the function of setting a GVLK key.

v1.0.2
 -Added function to delete the selected license.

v1.0.0
 -First version of the program.



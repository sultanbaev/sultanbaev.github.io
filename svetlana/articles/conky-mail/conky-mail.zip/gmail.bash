#!/bin/bash

login="ВАШ_ЛОГИН"
psswd="ВАШ_ПАРОЛЬ"

new=`curl -u ${login}:${psswd} -s "https://mail.google.com/mail/feed/atom" | grep -c "<entry>"`
echo $new
